<?php

return [
    'table' => [
        'digits_code' => 'Digits Code',
        'item_description' => 'Item Description',
        'qty' => 'Qty',
        'amount' => 'Amount',
        'reservable_qty' => 'Available Qty',
        'total_quantity' => 'Total Qty',
        'total_free_quantity' => 'Total Freebies Qty',
        'total_skus' => 'Total SKU',
        'total_free_skus' => 'Total Freebies',
        'action' => 'Action',
        'checkbox' => '',
    ],

    'form' => [
        'save' => 'Save',
        'back' => 'Back',
        'cancel' => 'Cancel'
    ]
];